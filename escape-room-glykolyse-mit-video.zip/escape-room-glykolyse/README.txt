# OPERATION ATP-BLACKOUT – Bio-Labor Escape Room (inkl. Introza.mp4)

## Wichtige Hinweise zum Starten & Hosten:
1. **Alle vier Labor-Bilder sind jetzt direkt in die `index.html` eingebettet!** Sie funktionieren ab sofort immer – auch ohne separaten `images/`-Ordner.
2. **Intro-Video einbinden:** Lege deine eigene Videodatei mit dem exakten Dateinamen **`Introza.mp4`** in denselben Ordner direkt neben die **`index.html`**.
3. Öffne die `index.html` im Browser – das Video erscheint direkt auf der Startseite im Einsatz-Briefing-Player und pausiert automatisch, sobald die Schülerinnen und Schüler auf „MISSION STARTEN“ klicken.
4. **Lehrkraft-Modus:** Unten rechts über `[Lehrkraft-Modus / Schnelltest]` erreichbar (PIN-Code: **1111**).
